<?php
use Phppot\DataSource;

require_once 'DataSource.php';
$db = new DataSource();
$conn = $db->getConnection();

//Class Upload
if (isset($_POST["import1"])) {
    
    $fileName = $_FILES["file"]["tmp_name"];
    
    if ($_FILES["file"]["size"] > 0) {
        
        $file = fopen($fileName, "r");
        
        while (($column = fgetcsv($file, 10000, ",")) !== FALSE) {
            
            $course = "";
            if (isset($column[0])) {
                $course = mysqli_real_escape_string($conn, $column[0]);
            }
            $meetcount = "";
            if (isset($column[1])) {
                $meetcount = mysqli_real_escape_string($conn, $column[1]);
            }
            
            $sqlInsert = "INSERT into usercourses (course,meetcount)
                   values (?,?)";
            $paramType = "si";
            $paramArray = array(
                $course,
                $meetcount
            );
            $insertId = $db->insert($sqlInsert, $paramType, $paramArray);
            
        }
    }
}

//Room Upload
if (isset($_POST["import2"])) {
    
    $fileName = $_FILES["file"]["tmp_name"];
    
    if ($_FILES["file"]["size"] > 0) {
        
        $file = fopen($fileName, "r");
        
        while (($column = fgetcsv($file, 10000, ",")) !== FALSE) {
            
            $rooms = "";
            if (isset($column[0])) {
                $rooms = mysqli_real_escape_string($conn, $column[0]);
            }
            
            $sqlInsert = "INSERT into rooms (rmNumber)
                   values (?)";
            $paramType = "s";
            $paramArray = array(
                $rooms
            );
            $insertId = $db->insert($sqlInsert, $paramType, $paramArray);
            
        }
    }
}



?>
<!DOCTYPE html>
<html>

<head>

<style>
            body {
                font-family: Arial;
                width: 1080px;
            }

            .outer-scontainer {
                background: #F0F0F0;
                border: #e0dfdf 1px solid;
                padding: 200px;
                border-radius: 2px;
            }

            .input-row {
                margin-top: 0px;
                margin-bottom: 20px;
            }

            .btn-submit {
                background: #333;
                border: #1d1d1d 1px solid;
                color: #f0f0f0;
                font-size: 0.9em;
                width: 100px;
                border-radius: 2px;
                cursor: pointer;
            }

            .outer-scontainer table {
                border-collapse: collapse;
                width: 100%;
            }

            .outer-scontainer th {
                border: 1px solid #dddddd;
                padding: 8px;
                text-align: left;
            }

            .outer-scontainer td {
                border: 1px solid #dddddd;
                padding: 8px;
                text-align: left;
            }

            div#response.display-block {
                display: block;
            }

            .navbar {
                overflow: hidden;
                background-color: #0051bc;
                position: fixed;
                top:0px;
                width: 100%;
            }

            .navbar a {
                float: left;
                display: block;
                color: #49b0d5;
                text-align: center;
                padding: 4px 32px;
                text-decoration: none;
                font-size: 17px;
            }

            .navbar a:hover {
                background: darkblue;
                color: orangered;
            }

            .outer-table {
                vertical-align: top
            }

            .outer-table td {
                vertical-align: top
            }

            .content-table {
                background:white;
                color:black;
                border-collapse:collapse;
                margin:25px 25px;
                font-size:0.9em;
                min-width: 400px;
                border-radius: 3px 3px 0 0;
                overflow: hidden;
                box-shadow: 0 0 30px rgba(0,0,0,0.20);
            }
            .content-table thead tr {
                background-color:#0051bc;
                color:white;
                text-align: left;
                font-weight: bold;
            }
            .content-table th,
            .content-table td {
                padding: 12px 15px;
            }

            .content-table tbody tr {
                border-bottom: 1px solid #dddddd;
            }

            .content-table tbody tr:nth-of-type(even) {
                background-color:#f3f3f3;
            }

            .content-table tbody tr:last-of-type  {
                border-bottom: 1px solid #0051bc;
            }

            .content-table tbody tr.active-row {
                font-weight: bold;
                color: orangered;
            }

            #nav-list {
                margin: 10px;
                list-style-type: none;
            }

            #nav-list li {
                display: inline-block;
                font-size: 18px;
                margin: 0px;
                margin-left: 0px;
                margin-right: 0px;
                vertical-align:bottom;
                line-height:normal;   
            }

            .main {
                padding: 14px;
                margin-top: 75px;
                height: 1500px;
            }
</style>

</head>

<body>
    <div class="navbar">
        
        <ul id="nav-list">
            <li><img src="bmcclogo.png"></li>
            <li><a href="#top">Upload</a></li>
            <li><a href="#schedule">Schedules</a></li>
        </ul>
        
    </div>

<div class="main">

    <h2>BMCC Class Scheduler</h2>

    <div id="response"
        class="<?php if(!empty($type)) { echo $type . " display-block"; } ?>">
        <?php if(!empty($message)) { echo $message; } ?>
        </div>

    <table id="outerTable" class="outer-table">
    <tr>
        <td>
    <div>
        <div>
            <form class="form-horizontal" action="" method="post"
                name="frmCSVImport" id="frmCSVImport"
                enctype="multipart/form-data">
                <div class="input-row">
                    <label class="col-md-4 control-label">Courses:</label> <input type="file" name="file"
                        id="file" accept=".csv">
                    <button type="submit" id="submit" name="import1"
                        class="btn-submit">Import</button>
                    <br />

                </div>

            </form>
        </td>
        <td>

            <form class="form-horizontal" action="" method="post"
                name="frmCSVImport" id="frmCSVImport"
                enctype="multipart/form-data">
                <div class="input-row">
                    <label class="col-md-4 control-label">Rooms:&nbsp;&nbsp; </label> <input type="file" name="file"
                        id="file" accept=".csv">
                    <button type="submit" id="submit" name="import2"
                        class="btn-submit">Import</button>
                    <br />

                </div>

            </form>

        </div>
        </td>

        <tr>
        <!--Table build starts here-->
        <td>
               <?php
            $sqlSelect = "SELECT * FROM usercourses";
            $result = $db->select($sqlSelect);
            if (! empty($result)) {
                ?>
            <table id='userTable' class='content-table'>
            <thead>
                <tr>
                    <th>Course</th>
                    <th>Meetings Per Week</th>

                </tr>
            </thead>
        <?php
                
                foreach ($result as $row) {
                    ?>
                    
                <tbody>
                <tr>
                    <td><?php  echo $row['course']; ?></td>
                    <td><?php  echo $row['meetcount']; ?></td>
                </tr>
                    <?php
                }
                ?>
                </tbody>
        </table>
        <?php } ?>
        </td>
        <td>

        <!--Secondary Table -->
        <?php
            $sqlSelect = "SELECT * FROM rooms";
            $result = $db->select($sqlSelect);
            if (! empty($result)) {
                ?>
            <table id='userTable' class='content-table'>
            <thead>
                <tr>
                    <th>Rooms</th>

                </tr>
            </thead>
        <?php
                
                foreach ($result as $row) {
                    ?>
                    
                <tbody>
                <tr>
                    <td><?php  echo $row['rmNumber']; ?></td>
                </tr>
                    <?php
                }
                ?>
                </tbody>
        </table>
        <?php } ?>
        </td>
        </tr>
    </div>
    </table>
    
        <!--Placeholder Schedule-->
        <a name="schedule"></a>
        <h1>Scheduled Sections</h1>
            <table class="content-table">
                <thead>
                    <tr>
                        <th>Course Number</th>
                        <th>Section Number</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>Room Number</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>CSC350</td>
                        <td>1200</td>
                        <td>1:00</td>
                        <td>3:45</td>
                        <td>F907</td>
                    </tr>
                    <tr class="active-row">
                        <td>CSC215</td>
                        <td>0900</td>
                        <td>9:00</td>
                        <td>10:50</td>
                        <td>F1203</td>
                    </tr>
                    <tr>
                        <td>CSC101</td>
                        <td>160W</td>
                        <td>4:00</td>
                        <td>6:00</td>
                        <td>F907</td>
                    </tr>
                </tbody>
            </table>

        <h1>Weekly Schedule</h1>
        <table class="content-table">
            <thead>
                <tr>
                    <th>Room Number</th>
                    <th>Monday</th>
                    <th>Tuesday</th>
                    <th>Wednesday</th>
                    <th>Thursday</th>
                    <th>Friday</th>
                    <th>Saturday</th>
                    <th>Sunday</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>F901</td>
                    <td>NULL</td>
                    <td>NULL</td>
                    <td>NULL</td>
                    <td>NULL</td>
                    <td>NULL</td>
                    <td>NULL</td>
                    <td>NULL</td>
                </tr>
                <tr>
                    <td>F906</td>
                    <td>NULL</td>
                    <td>NULL</td>
                    <td>NULL</td>
                    <td>NULL</td>
                    <td>NULL</td>
                    <td>NULL</td>
                    <td>NULL</td>
                </tr>
            </tbody>
        </table>
        <!--End of Placeholder-->

</div>
</body>

</html>